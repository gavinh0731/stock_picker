self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dac995af187c833fd1b5b060c1d4bd32",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "0921c9edc6c2915785bb218fb374f08f",
    "url": "/stockmoney/json.tgz"
  },
  {
    "revision": "66b14de9d3dac31a1d4ccb3cece5daa5",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "37835bce95e4c1da2db45f685e774edd",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "6787cc2dbac1fcfa45d1a124d54ccd60",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "dd90102361527a006b896faac2145699",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "e066b47476dfe4072b7ba0951cb1495b",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "bab3a32f4be249535b3a66346615df17",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "551f587500a728b579b6167180f7bb14",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "17f8903b961e62786a89d063dbd38c37",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "c22785e4389d46c91506472f642c8c64",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "078407a671875caae3f84a7ebd7abc29",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "b2952c3c3561362a8a1e9b1f2fc0ac9e",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "4a01d4330b10e31c6048acfe2d9dde98",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "1977f35ddda14114b797ab61e817e92c",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "a4ec90657eeb9c83a7e2f98fd3c3f5e7",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "3ddf8bef6367b145fce6d5fc7a98bca1",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "5728987db1e5d5f523726df95a534bf2",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "66d9182b66791b797faede6ffc6efd56",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "7065679ecfb13f0a0a85bddd56367236",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "a252c14cb67ae029cc8cf88884186642",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "5203986bb5620536a964ecd7b61294bd",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "e6fb579d1fbd5552c3e2d24e298b145f",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "d5efdeb263e6da3d7d4feb4cef420dfd",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "48a3a5486abdeab7eb92f859170445f0",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "3bf6b3dc1976b822f2443d8ebde9211f",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "98329a6ded9059ab3486d8f0c4a424b0",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "6ef62878afdb2417b148480e5f023184",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "aae3a6e885039beab284dc3e93725146",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "226da291dc547f3ec54bd7dbf41709c4",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "d57c2aa7f683a2d4f3644d6a82a616b8",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "973a62564e9f47af75e8606ba68c1897",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "b3533c6d167d3d1500695a8eb9663cf5",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "eea466d749e3dd858b97ec649ada95aa",
    "url": "/stockmoney/json/chip_holder.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/chip_holder_cols.json"
  },
  {
    "revision": "749265c77a715c62ee765cc15d451340",
    "url": "/stockmoney/json/chip_holder_up.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/chip_holder_up_cols.json"
  },
  {
    "revision": "7f8d93db42068cc34c3f97da8fe164dd",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "e74d13736132d4bb841beb3cc720aaab",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "495102c9ca3b6a6567ef7f9897a890ea",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "ac675ec09289a78c1cd1ce4df4e89ad1",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "536dfd3297546bf2589fc8241ea00cab",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "ec9e59c52a4f922af613534e20ada903",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "3e8dc99836816cdedc952a126db1fa79",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "625222a47ba70beec0d3d4bb2061d957",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "901ce3931f9ef8c83609b50fafb6bee8",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b47da97faeb4b3853983637a8f9d2d0c",
    "url": "/stockmoney/json/dividend_stat_2020.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/dividend_stat_2020_cols.json"
  },
  {
    "revision": "09be49e38c5d1ca86ea5eeee8f932f39",
    "url": "/stockmoney/json/dividend_stat_2021.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/dividend_stat_2021_cols.json"
  },
  {
    "revision": "68ba83f5d3d339fc9bf071f2c8db5d2e",
    "url": "/stockmoney/json/dividend_stat_2022.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/dividend_stat_2022_cols.json"
  },
  {
    "revision": "a04bdc89d54043f8fa5add4d124a0e36",
    "url": "/stockmoney/json/dividend_stat_2023.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/dividend_stat_2023_cols.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "e5c711ef4886caedf9cbd7d4aafa3b19",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/dk_dies.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/dk_dies_cols.json"
  },
  {
    "revision": "e0bade0588f97c4131a4d5eb42797324",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "618b94f5d0786c7401b52944ab7706ed",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "8a782513b99c4e31cf07aca4745c38e4",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "c4ee44506f572de9c92fffb84d3c7fa0",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "24c365c317bd950273a6bbe79b14d791",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "733aca7c28c91246199726785756852b",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "29e0c2731cf0823c503af4580b581346",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "c634c8fec12d0bdb2704e40ae60b888d",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1743dc326779ed0d0955118930c2fdc1",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "0a4bed0c9cc2d92e63ce949a2090d425",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "094964f448b8daf6f52f6a4c3fc25922",
    "url": "/stockmoney/json/my_basic.json"
  },
  {
    "revision": "b3b795fa1a32bed358c5a424550eaece",
    "url": "/stockmoney/json/my_basic_cols.json"
  },
  {
    "revision": "778c2668edd6baded2fd987c69ac04df",
    "url": "/stockmoney/json/my_chip.json"
  },
  {
    "revision": "9a4e135bd706cb00ba1b6ccd50cde83a",
    "url": "/stockmoney/json/my_chip_cols.json"
  },
  {
    "revision": "6668d5f573d38fa1069ce6cef5268b71",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "20ee2a310a6be51a7bbe4ab235a48dba",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "7ca1c515adeac8535e5212dd50cbef08",
    "url": "/stockmoney/json/my_tech.json"
  },
  {
    "revision": "4b39153da2d47c317e3bf1ded1a14cf5",
    "url": "/stockmoney/json/my_tech_cols.json"
  },
  {
    "revision": "056dbaba575906c26f3680326d737f6a",
    "url": "/stockmoney/json/price_dpct.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/price_dpct_cols.json"
  },
  {
    "revision": "742f506cdfc8a72ce4064675584bba8b",
    "url": "/stockmoney/json/price_high.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/price_high_cols.json"
  },
  {
    "revision": "fa7ed641982a9f7ccdcffbe757a45830",
    "url": "/stockmoney/json/price_mpct.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/price_mpct_cols.json"
  },
  {
    "revision": "b6e9e4c54e73245ca7df23e0c86e603c",
    "url": "/stockmoney/json/price_wpct.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/price_wpct_cols.json"
  },
  {
    "revision": "7580b526649e2cbad0c63f3af7689777",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "a25fba5912b466f87c02f7f34acfeafc",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "bda0431a2c94a3be22ae6ec9f0218f1f",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "6850d86fec3624de541b2b1a40282c01",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "7ef56aa3810a9f7d6cd53f9f6e03214f",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "5c125157702e4475325fc62420500833",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "31316b97678e8ae0cb5212ebfd25f804",
    "url": "/stockmoney/json/tech_macd.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/tech_macd_cols.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/tech_makink.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/tech_makink_cols.json"
  },
  {
    "revision": "735cf83e7da4d915146c7188a8824ece",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "4584935e643a019adbbe29abbce278fd",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "8e328e6ec691cd03765f95f58d4ae546",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "abf3ffa9622f2612ab72df1c363bd151",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "e4632e1b9287bf49032c00970f6290c2",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "69db386ce28079522d416de746dc82ed",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "5db6583aab0ddee48447b22a8d797857",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "88e7ff2290852191df9cbdff25cc27df",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "f13caf6ad3715a8243596406079b1709",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "d95148055839b0af67b9f20145ebc9ce",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "7f5e91241f41d6d2a66c1ced75d907aa",
    "url": "/stockmoney/json/year_yield.json"
  },
  {
    "revision": "d8dd3eb15ae3cc3df48b166729a9fe7d",
    "url": "/stockmoney/json/year_yield_cols.json"
  },
  {
    "revision": "af69b77416a2ab024bde6ee51935eda5",
    "url": "/stockmoney/json_otc.tgz"
  },
  {
    "revision": "32177d9a6f658788332c7b27ee98b16c",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "f5380985bb5f10cb8806a72a79011683",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "72bb5d2420bbe1194e2bd0b0bca85f51",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "dd90102361527a006b896faac2145699",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "2f182d614801a0df4dd976dc901d02a9",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "bab3a32f4be249535b3a66346615df17",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "dd0376ef92f65537d913fa947de31f5b",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "17f8903b961e62786a89d063dbd38c37",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "8fd6feae0a5ad053efd4eae1a7024b17",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "078407a671875caae3f84a7ebd7abc29",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "bb1cf580991414bd631e998f25ef9e6e",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "4a15429f3f6f8d3ced7c1452680509d5",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "a4ec90657eeb9c83a7e2f98fd3c3f5e7",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "c046d840f0e4ec88dfb49fb07487626e",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "5728987db1e5d5f523726df95a534bf2",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "e54f1f0b0c03dac0ad4a546a91875d84",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "7065679ecfb13f0a0a85bddd56367236",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "f32798b3f79acdff4041ecf2abc90661",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "5203986bb5620536a964ecd7b61294bd",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "e9892640cd4c5a0ff7716bf3428f79dd",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "d5efdeb263e6da3d7d4feb4cef420dfd",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "59d7f09f7928ce757b319aac4a0f46a5",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "3bf6b3dc1976b822f2443d8ebde9211f",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "a159be5f7d358baeee8c19075390ecd9",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "dca996364de34d3ddf010ad2501f7692",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "3dc8075554c71da6af9af4cf88de863f",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "e9edc53acedd5ed53b25a6ea7b948780",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "c438c9a561bffafbe6a2e2380a51a159",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "cbfc9c3629c9a5fa8f0d1d0b0d025337",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "813cd4a59976456ba1052708cc478b6a",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "777726a10b104fb8cf60ba1fdaf92eee",
    "url": "/stockmoney/json_otc/chip_holder.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_holder_cols.json"
  },
  {
    "revision": "cd329ddeffd175d9d9f58a621f7b1dd1",
    "url": "/stockmoney/json_otc/chip_holder_up.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_holder_up_cols.json"
  },
  {
    "revision": "f782087678209f727b13f5b25b257574",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "bfd4d0d40573c9446248d17a12f8a547",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "0e5962467f89d2ec154d8dadf2d5cf2f",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "f2631371778e28d5ef4376e437736fc5",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "b0c4d9eadae7bba24e859689a518b546",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "9b1f2eb4a20319f0f20f21e476773edb",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "e1ff3dd07082502150fe3f356e534516",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "35b8ee337fb6dffdfe2657c9f5d496f5",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "6618c4f6ca555db29807ce20dde138eb",
    "url": "/stockmoney/json_otc/dividend_stat_2020.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/dividend_stat_2020_cols.json"
  },
  {
    "revision": "cf57cdb3c7c3e2ee5273e958e44cfd5e",
    "url": "/stockmoney/json_otc/dividend_stat_2021.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/dividend_stat_2021_cols.json"
  },
  {
    "revision": "db459af779eeea1e8ba145de928c5082",
    "url": "/stockmoney/json_otc/dividend_stat_2022.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/dividend_stat_2022_cols.json"
  },
  {
    "revision": "065140c5c3f161834b58a1851ba83643",
    "url": "/stockmoney/json_otc/dividend_stat_2023.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/dividend_stat_2023_cols.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "7648443d0a97d1620e53d1b1d8f8e26a",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "35cf724f4dece037cc70e26ef15751c4",
    "url": "/stockmoney/json_otc/price_dpct.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/price_dpct_cols.json"
  },
  {
    "revision": "3ae85ea6ba20cc8ae345b68c9329fef2",
    "url": "/stockmoney/json_otc/price_mpct.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/price_mpct_cols.json"
  },
  {
    "revision": "d3a4a370bac40b3a16a4f067a13aa852",
    "url": "/stockmoney/json_otc/price_wpct.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/price_wpct_cols.json"
  },
  {
    "revision": "d2e447da5fa8021cf9cd2ef17d35fb92",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "f36c8b4068aff2cc73deaf4cda1c052d",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "d75037b75cf5f606a4015dc20498ec40",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "aa26bdef2596f2bd6895754c7ee0a1ca",
    "url": "/stockmoney/json_otc/tech_macd.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/tech_macd_cols.json"
  },
  {
    "revision": "a609c176837f1ebaf0cfe63d87c815a3",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "4584935e643a019adbbe29abbce278fd",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "f0b5085b292b24400164ce09bcb1da05",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "abf3ffa9622f2612ab72df1c363bd151",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "a779e1920061d835084fcff45a27171c",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "69db386ce28079522d416de746dc82ed",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "03d439d97ab71062ea232ec2ec18c7c2",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "88e7ff2290852191df9cbdff25cc27df",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "70df1d261311f31e4a3b639c4a79012f",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "d95148055839b0af67b9f20145ebc9ce",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "f226bc2146601359b276dce19f0b20f7",
    "url": "/stockmoney/json_otc/year_yield.json"
  },
  {
    "revision": "d8dd3eb15ae3cc3df48b166729a9fe7d",
    "url": "/stockmoney/json_otc/year_yield_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "19b39503f7d5a8d638da",
    "url": "/stockmoney/static/css/app.f7baddb7.css"
  },
  {
    "revision": "a78580313a4e99f0a0f2",
    "url": "/stockmoney/static/css/chunk-vendors.d4a60ab3.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "dbaa803f7c71b452ab5a",
    "url": "/stockmoney/static/js/about.95f00123.js"
  },
  {
    "revision": "19b39503f7d5a8d638da",
    "url": "/stockmoney/static/js/app.7c3f34ed.js"
  },
  {
    "revision": "a78580313a4e99f0a0f2",
    "url": "/stockmoney/static/js/chunk-vendors.4bb69bda.js"
  }
]);